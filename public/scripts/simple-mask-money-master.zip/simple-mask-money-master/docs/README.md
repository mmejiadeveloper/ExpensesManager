<h1 align="center">Documentation SimpleMaskMoney</h1>
<h3 align="center"><b>WARNING</b></h3>
<h5 align="center">
  if you are having problems check the version you are using.
  <a href="2.x.x/#readme">
    The docs to old (2.x.x) version stay <b>here</b>
  </a>
</h5>

<p align="center">
  Simple money mask use a <a href="https://semver.org/">semver (semantic version)</a> please read api the docs equivalent to your version or if you prefer <a href="../examples/#readme">see the examples</a>.
</p>

[**3.x.x**](3.x.x/#readme)

[**2.x.x**](2.x.x/#readme)
