# SimpleMaskMoney Exemple React
First, install it.
```shell
  npm i simple-mask-money --save
```
Then, use it as follows:
#(Not Implemented)
Help-me to implement